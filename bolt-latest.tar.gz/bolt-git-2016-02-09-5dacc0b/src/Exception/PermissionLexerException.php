<?php

namespace Bolt\Exception;

/**
 * Signals an error in the lexer.
 */
class PermissionLexerException extends \Exception
{
}
