<?php

namespace Bolt\Exception;

class ExtensionsInfoServiceException extends \Exception
{
}
