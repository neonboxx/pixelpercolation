<?php

namespace Bolt\Exception;

/**
 * Exceptions in Bolt\Storage.
 */
class StorageException extends \Exception
{
}
